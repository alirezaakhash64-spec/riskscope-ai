RiskScope AI v0.1

Files:
- index.html
- styles.css
- script.js
- assets/riskscope-logo.png

MVP rules:
- 5 free analyses stored in browser localStorage
- No login
- No payment yet
- Educational only, not financial advice

Mobile-friendly launch path:
1. Create a GitHub account.
2. Create a new repository named riskscope-ai.
3. Upload all files from this folder.
4. Connect the repository to Vercel.
5. Deploy for free.
